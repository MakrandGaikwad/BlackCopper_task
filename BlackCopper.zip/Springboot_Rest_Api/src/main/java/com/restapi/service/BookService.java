package com.restapi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.restapi.entity.Book;

@Component
public class BookService {

	private static List<Book> list = new ArrayList<>();
	
	static
	{
		list.add(new Book(12,"math","sham"));
		list.add(new Book(18,"Science","Ram"));
		list.add(new Book(1234,"Eng","Jery"));
	}

	//get all books service
	public List<Book>  getAllBooks()
	{
		return list;
	}
	
	//get single book by id
	public Book getBookById( int id)
	{
		Book book=null;
		book=list.stream().filter(r-> r.getId()==id).findFirst().get();
		
		return book;
	}
	
	//Adding the book
	public Book addBook(Book b)
	{
		list.add(b);
		return b;
	}
	
	//deleting the book by id
		public void deleteBook( int id)
		{
			//here, stream() is used to convert list into stream, and filter() is used to filter that stream according to the given predicate/condition
	         // filter() method accepts predicate/condition as an argument
			
			list=list.stream().filter(book-> book.getId()!=id).collect(Collectors.toList());
			
		}
		
		
		//update the book
		public void updateBook(Book book, int id)
		{
			//here, map function checks for each and every object...from the given stream
			list = list.stream().map(b -> {
				if(b.getId()==id) 
				{
					b.setName(book.getName());
					b.setAuthor(book.getAuthor());
				}
				return b;
			}).collect(Collectors.toList());
		}
}
